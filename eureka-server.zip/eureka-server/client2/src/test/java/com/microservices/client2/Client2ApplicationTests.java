package com.microservices.client2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Client2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
